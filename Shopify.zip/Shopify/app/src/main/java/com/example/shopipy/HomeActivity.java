package com.example.shopipy;

import android.app.Activity;

public class HomeActivity extends Activity {
}
